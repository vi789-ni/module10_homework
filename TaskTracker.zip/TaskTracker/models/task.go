package models

import (
	"errors"
	"strings"
	"sync"
)

type Task struct {
	ID        int
	Title     string
	Completed bool
}

type PageData struct {
	Tasks          []Task
	TotalTasks     int
	CompletedTasks int
	PendingTasks   int
	ErrorMessage   string
}

type TaskStore struct {
	mu     sync.Mutex
	tasks  []Task
	nextID int
}

func NewTaskStore() *TaskStore {
	return &TaskStore{
		tasks:  make([]Task, 0),
		nextID: 1,
	}
}

func (s *TaskStore) AddTask(title string) (Task, error) {
	trimmed := strings.TrimSpace(title)
	if trimmed == "" {
		return Task{}, errors.New("название задачи не может быть пустым")
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	task := Task{
		ID:        s.nextID,
		Title:     trimmed,
		Completed: false,
	}
	s.nextID++
	s.tasks = append(s.tasks, task)
	return task, nil
}

func (s *TaskStore) FindTaskIndex(id int) int {
	for i, t := range s.tasks {
		if t.ID == id {
			return i
		}
	}
	return -1
}

func (s *TaskStore) ToggleTask(id int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	idx := s.FindTaskIndex(id)
	if idx == -1 {
		return errors.New("задача с указанным ID не найдена")
	}

	s.tasks[idx].Completed = !s.tasks[idx].Completed
	return nil
}

func (s *TaskStore) DeleteTask(id int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	idx := s.FindTaskIndex(id)
	if idx == -1 {
		return errors.New("задача с указанным ID не найдена")
	}

	s.tasks = append(s.tasks[:idx], s.tasks[idx+1:]...)
	return nil
}

func (s *TaskStore) GetPageData(errorMsg string) PageData {
	s.mu.Lock()
	defer s.mu.Unlock()

	copiedTasks := make([]Task, len(s.tasks))
	copy(copiedTasks, s.tasks)

	completed := 0
	for _, t := range copiedTasks {
		if t.Completed {
			completed++
		}
	}

	total := len(copiedTasks)
	pending := total - completed

	return PageData{
		Tasks:          copiedTasks,
		TotalTasks:     total,
		CompletedTasks: completed,
		PendingTasks:   pending,
		ErrorMessage:   errorMsg,
	}
}
