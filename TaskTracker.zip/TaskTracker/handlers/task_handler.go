package handlers

import (
	"html/template"
	"net/http"
	"net/url"
	"path/filepath"
	"strconv"

	"TaskTracker/models"
)

type TaskHandler struct {
	store     *models.TaskStore
	indexTmpl *template.Template
	aboutTmpl *template.Template
}

func NewTaskHandler(store *models.TaskStore, templatesDir string) (*TaskHandler, error) {
	indexTmpl, err := template.ParseFiles(filepath.Join(templatesDir, "index.html"))
	if err != nil {
		return nil, err
	}

	aboutTmpl, err := template.ParseFiles(filepath.Join(templatesDir, "about.html"))
	if err != nil {
		return nil, err
	}

	return &TaskHandler{
		store:     store,
		indexTmpl: indexTmpl,
		aboutTmpl: aboutTmpl,
	}, nil
}

func (h *TaskHandler) Home(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	if r.Method != http.MethodGet {
		http.Error(w, "Метод не поддерживается", http.StatusMethodNotAllowed)
		return
	}

	errMsg := r.URL.Query().Get("error")
	data := h.store.GetPageData(errMsg)

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := h.indexTmpl.Execute(w, data); err != nil {
		http.Error(w, "Ошибка рендеринга шаблона", http.StatusInternalServerError)
	}
}

func (h *TaskHandler) CreateTask(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Метод не поддерживается", http.StatusMethodNotAllowed)
		return
	}

	title := r.FormValue("title")
	if _, err := h.store.AddTask(title); err != nil {
		h.redirectWithError(w, r, err.Error())
		return
	}

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func (h *TaskHandler) ToggleTask(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Метод не поддерживается", http.StatusMethodNotAllowed)
		return
	}

	id, err := parseTaskID(r)
	if err != nil {
		h.redirectWithError(w, r, err.Error())
		return
	}

	if err := h.store.ToggleTask(id); err != nil {
		h.redirectWithError(w, r, err.Error())
		return
	}

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func (h *TaskHandler) DeleteTask(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Метод не поддерживается", http.StatusMethodNotAllowed)
		return
	}

	id, err := parseTaskID(r)
	if err != nil {
		h.redirectWithError(w, r, err.Error())
		return
	}

	if err := h.store.DeleteTask(id); err != nil {
		h.redirectWithError(w, r, err.Error())
		return
	}

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func (h *TaskHandler) About(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Метод не поддерживается", http.StatusMethodNotAllowed)
		return
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := h.aboutTmpl.Execute(w, nil); err != nil {
		http.Error(w, "Ошибка рендеринга шаблона", http.StatusInternalServerError)
	}
}

func parseTaskID(r *http.Request) (int, error) {
	rawID := r.FormValue("id")
	if rawID == "" {
		return 0, errInvalidID()
	}
	id, err := strconv.Atoi(rawID)
	if err != nil || id <= 0 {
		return 0, errInvalidID()
	}
	return id, nil
}

type invalidIDError struct{}

func (invalidIDError) Error() string { return "некорректный идентификатор задачи" }

func errInvalidID() error { return invalidIDError{} }

func (h *TaskHandler) redirectWithError(w http.ResponseWriter, r *http.Request, msg string) {
	target := "/?error=" + url.QueryEscape(msg)
	http.Redirect(w, r, target, http.StatusSeeOther)
}
