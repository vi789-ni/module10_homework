package main

import (
	"log"
	"net/http"

	"TaskTracker/handlers"
	"TaskTracker/models"
)

func main() {
	store := models.NewTaskStore()

	taskHandler, err := handlers.NewTaskHandler(store, "templates")
	if err != nil {
		log.Fatalf("Ошибка инициализации шаблонов: %v", err)
	}

	mux := http.NewServeMux()

	fileServer := http.FileServer(http.Dir("static"))
	mux.Handle("/static/", http.StripPrefix("/static/", fileServer))

	mux.HandleFunc("/", taskHandler.Home)
	mux.HandleFunc("/tasks", taskHandler.CreateTask)
	mux.HandleFunc("/tasks/complete", taskHandler.ToggleTask)
	mux.HandleFunc("/tasks/delete", taskHandler.DeleteTask)
	mux.HandleFunc("/about", taskHandler.About)

	addr := ":8080"
	log.Printf("Server started: http://localhost%s\n", addr)
	log.Fatal(http.ListenAndServe(addr, mux))
}
